package onlinefooddelivery.model;

public class Menu extends Restaurant{
	private int quantity;
	
	
	public Menu(){
	}
	
	public int getQuantity() {
		return quantity;
	}
	
	public void setQuantity(int quantity) {
		this.quantity=quantity;
	}
		
	}

